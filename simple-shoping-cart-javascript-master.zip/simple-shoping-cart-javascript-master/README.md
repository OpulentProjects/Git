# Shopping cart in Vanilla JavaScript

Simple shopping cart based on Vanilla Javascript
